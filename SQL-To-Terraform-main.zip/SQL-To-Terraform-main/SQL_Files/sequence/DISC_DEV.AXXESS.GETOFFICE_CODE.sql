create or replace sequence DISC_DEV.TEST.GETOFFICE_CODE start with -8 increment by -1 order;
