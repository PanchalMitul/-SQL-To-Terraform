create or replace sequence DISC_DEV.TEST.TESTDG_1 start with -8 increment by -1 order;
