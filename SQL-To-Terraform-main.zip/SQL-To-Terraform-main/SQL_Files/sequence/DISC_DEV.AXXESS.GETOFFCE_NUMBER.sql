create or replace sequence DISC_DEV.DEMO.GETOFFCE_NUMBER start with 8659 increment by 1 order;
