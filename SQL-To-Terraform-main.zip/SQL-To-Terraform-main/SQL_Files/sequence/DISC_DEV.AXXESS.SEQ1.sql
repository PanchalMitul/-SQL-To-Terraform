create or replace sequence DISC_DEV.TEST.SEQ1 start with 1 increment by 1 order;
